package School_김진수;

public class _Main {

	public static void main(String[] args) {
		Controller c = new Controller();
		c.run();
	}

}
